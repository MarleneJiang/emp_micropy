from distutils.core import setup

setup(
    name='emp-marlene',
    version='0.0.1',
    py_modules=['emp_wifi', 'emp_boot', 'emp_ide', 'emp_utils', 'emp_webrepl'],
    author='marlene',
    author_email='',
    url='http://emp.marlene.top/',
    description='EMP(Easy MicroPython) is a upy module to make things Easy on MicroPython.'
)
